<?php
require_once __DIR__ . '/config.php';

$actionDone = '';
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $secret = $_POST['secret'] ?? '';
    if ($secret === ACTIVATION_SECRET) {
        if (file_exists(ACTIVATED_FILE)) {
            unlink(ACTIVATED_FILE);
            $actionDone = 'Activation revoked (activated.json removed).';
        } else {
            $actionDone = 'No activation file found.';
        }
    } else {
        $error = 'Invalid secret.';
    }
}
?>
<!doctype html><html><head><meta charset="utf-8"><title>Reset Activation</title></head><body>
<div style="max-width:700px;margin:20px;">
<h3>Reset / Revoke Activation</h3>
<?php if ($actionDone): ?>
    <div style="color:green;"><?=htmlspecialchars($actionDone)?></div>
<?php endif; ?>
<?php if ($error): ?>
    <div style="color:red;"><?=htmlspecialchars($error)?></div>
<?php endif; ?>
<form method="post">
    <p>Enter the activation secret to remove activation (keeps your secret in config.php):</p>
    <input type="password" name="secret" style="width:60%"><br><br>
    <button type="submit">Reset Activation</button>
</form>
</div>
</body></html>
